# Newsletter Bootstrap - Bài thực hành phối màu

Project gồm 2 phiên bản newsletter responsive, sử dụng Bootstrap 5.3.3 và CSS Variables.

## Version 1
- Primary: #0C66E4
- Secondary: #36B37E
- Accent: #FFAB00
- Light background: #E9F2FF
- Dark: #172B4D

## Version 2
- Primary: #6F42C1
- Secondary: #D9485F
- Accent: #F59F00
- Light background: #F7F0FF
- Dark: #2D2342

Hai phiên bản có cùng cấu trúc newsletter nhưng dùng hai bộ màu khác nhau.

## Chạy bài
Mở `version1/index.html` hoặc `version2/index.html` bằng trình duyệt.
Bootstrap được liên kết qua CDN.

## Nộp GitHub
Upload toàn bộ thư mục project lên repository GitHub.
